<?php require_once('url.php') ?>
<html>
 <head>
  <title>libsensorPy</title>
 </head>
 <body>
 <?php echo "<p>LibsensorPy</p>"; ?>
 <?php include $folder.'/'.$page.'.php'; ?>
 </body>
</html>
