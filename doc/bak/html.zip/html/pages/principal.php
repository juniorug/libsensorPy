<html>
 <head>
  <title>PHP Teste</title>
 </head>
 <body>
 <?php echo "<p>Olá Mundo! voce está em principal.php</p>"; ?>
 </body>
</html>
